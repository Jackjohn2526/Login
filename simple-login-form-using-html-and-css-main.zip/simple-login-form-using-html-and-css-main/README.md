# simple-login-form-using-html-and-css
Simple Login Form Using HTML &amp; CSS Only


Watch Tutorial Video Here : https://youtu.be/DB1V0XSlrOc

Create a simple login form using HTML and CSS Only. Just by using a text editor and browser on your laptop or computer.

IG : @janzen.faidiban
GitHub : @janzenfaidiban
